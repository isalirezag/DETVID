# --------------------------------------------------------
# Fast/er R-CNN
# Licensed under The MIT License [see LICENSE for details]
# Written by Bharath Hariharan
# --------------------------------------------------------
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import xml.etree.ElementTree as ET
import os
import pickle
import numpy as np

classes_map = ('__background__',  # always index 0
               'n02691156', 'n02419796', 'n02131653', 'n02834778',
               'n01503061', 'n02924116', 'n02958343', 'n02402425',
               'n02084071', 'n02121808', 'n02503517', 'n02118333',
               'n02510455', 'n02342885', 'n02374451', 'n02129165',
               'n01674464', 'n02484322', 'n03790512', 'n02324045',
               'n02509815', 'n02411705', 'n01726692', 'n02355227',
               'n02129604', 'n04468005', 'n01662784', 'n04530566',
               'n02062744', 'n02391049')

classes = ('__background__',  # always index 0
           'airplane', 'antelope', 'bear', 'bicycle',
           'bird', 'bus', 'car', 'cattle',
           'dog', 'domestic_cat', 'elephant', 'fox',
           'giant_panda', 'hamster', 'horse', 'lion',
           'lizard', 'monkey', 'motorcycle', 'rabbit',
           'red_panda', 'sheep', 'snake', 'squirrel',
           'tiger', 'train', 'turtle', 'watercraft',
           'whale', 'zebra')

cls_map_to_inds = dict(zip(classes_map, range(len(classes_map))))
inds_to_cls = dict(zip(range(len(classes_map)), classes))


def parse_rec(filename):
    """ Parse a PASCAL VOC xml file """
    tree = ET.parse(filename)
    objects = []
    for obj in tree.findall('object'):
        obj_struct = {}
        obj_struct['name'] = obj.find('name').text

        bbox = obj.find('bndbox')
        obj_struct['bbox'] = [int(bbox.find('xmin').text) + 1,
                              int(bbox.find('ymin').text) + 1,
                              int(bbox.find('xmax').text) + 1,
                              int(bbox.find('ymax').text) + 1]
        objects.append(obj_struct)

    return objects


def vid_ap(rec, prec, use_07_metric=False):
    """ ap = vid_ap(rec, prec, [use_07_metric])
    Compute VOC AP given precision and recall.
    If use_07_metric is true, uses the
    VOC 07 11 point method (default:False).
    """
    if use_07_metric:
        # 11 point metric
        ap = 0.
        for t in np.arange(0., 1.1, 0.1):
            if np.sum(rec >= t) == 0:
                p = 0
            else:
                p = np.max(prec[rec >= t])
            ap = ap + p / 11.
    else:
        # correct AP calculation
        # first append sentinel values at the end
        mrec = np.concatenate(([0.], rec, [1.]))
        mpre = np.concatenate(([0.], prec, [0.]))

        # compute the precision envelope
        for i in range(mpre.size - 1, 0, -1):
            mpre[i - 1] = np.maximum(mpre[i - 1], mpre[i])

        # to calculate area under PR curve, look for points
        # where X axis (recall) changes value
        i = np.where(mrec[1:] != mrec[:-1])[0]

        # and sum (\Delta recall) * prec
        ap = np.sum((mrec[i + 1] - mrec[i]) * mpre[i + 1])
    return ap


def vid_eval_map(detpath,
             annopath,
             imagesetfile, 
             AllAnnoInfo_VID,
             allclasses,
             cachedir,
             ovthresh=0.5,
             use_07_metric=False):
    
    
    if not os.path.isdir(cachedir):
        os.mkdir(cachedir)
    cachefile = os.path.join(cachedir, 'annots.pkl')

    # All images name
    imagenames = AllAnnoInfo_VID
    
    # load annotations
    recs = {}
    for i, imagename in enumerate(imagenames):
        recs[imagename] = parse_rec(imagename)
        if i % 100 == 0:
            print('Reading annotation for {:d}/{:d}'.format(
                i + 1, len(imagenames)))
    # save
    print('Saving cached annotations to {:s}'.format(cachefile))
    with open(cachefile, 'wb') as f:
        pickle.dump(recs, f)
    
    # recs includes the anotation for all the images
    
    
    # extract gt objects for all classes for each image and compute the map for that image
    R = {}
    ClassesinImage = {}
    x = []
    bbox = {}
    class_recs = {}
    Classes_With_BBOXES = {}
    npos = 0
    LISTALLIMAGE = []
    ccc=0
    
    ALLD = {}
    for classname_GT_TXT in  allclasses:
        if classname_GT_TXT == '__background__':
            continue
    ## read the detections for that class
        detfile = detpath.format(classname_GT_TXT)
        with open(detfile, 'r') as f:
            lines = f.readlines()
        
    # choose if the image we are cosidering has any detection for that class or not
        ALLD[classname_GT_TXT] = {}
        for iii in lines:
#            if iii.split()[0] == imagename:
                if iii.split()[0] in ALLD:
                    ALLD[classname_GT_TXT][iii.split()[0]].append(iii.split()[1:])
                else:
                    ALLD[classname_GT_TXT][iii.split()[0]] = []
                    ALLD[classname_GT_TXT][iii.split()[0]].append(iii.split()[1:])

    for imagename in imagenames:
        ccc+=1
        
        bbox = {}
        R = {}
        ClassesinImage = {}
        x = []
        bbox = {}
        class_recs = {}
        Classes_With_BBOXES = {}
        npos = 0
#        print(ccc)
        # what is R
        # tells us how many classes are in this image, also it includes gt bbox
        ClassesinImage = {}
        for classname in allclasses:
                for objclasses in recs[imagename]:
                    if objclasses['name'] == classname:
                        if classname in ClassesinImage:
                            ClassesinImage[classname].append(objclasses)
                        else:
                            ClassesinImage[classname]=[]
                            ClassesinImage[classname].append(objclasses)
                            
        for KEYS in ClassesinImage.keys():
            for xx in ClassesinImage[KEYS]:
                
                if KEYS in bbox:
                    bbox[KEYS].append(np.array(xx['bbox']))
                else:
                    bbox[KEYS] = []
                    bbox[KEYS].append(np.array(xx['bbox']))
                    
        # bbox is the gt bbox for each class that exist in this image
                

                    
                    

        npos = 0 # number of positive for this class
        for KEYS in ClassesinImage.keys():
            det = [False] * len(ClassesinImage[KEYS]) # what is DET for????
            npos = npos + len(ClassesinImage[KEYS])
#            if len(ClassesinImage[KEYS])>1:
#                print(len(ClassesinImage[KEYS]))
            Classes_With_BBOXES[KEYS] = {'bbox': np.unique(bbox[KEYS],axis=0),
                                     'det': det}
            
        # compute map for each class in one image
        ImagemAP = []
        NAMEImagemAP = []
        ImagemAP2 = []#[imagename classname_GT_TXT] Classes_With_BBOXES
#        for classname_GT_TXT in Classes_With_BBOXES.keys():#allclasses:
# =============================================================================
        for classname_CheckingNow in  allclasses:
            
            if imagename in ALLD[classname_CheckingNow].keys():
                
                #computing mAP for image imagename for class  classname_CheckingNow
                Alldetection_forthisClass_forthisImage = ALLD[classname_CheckingNow][imagename]

                confidence = np.array([float(x[0]) for x in Alldetection_forthisClass_forthisImage])
                BB = np.array([[float(z) for z in x[1:]] for x in Alldetection_forthisClass_forthisImage])

                numberofdetection = len(Alldetection_forthisClass_forthisImage)
                tp = np.zeros(numberofdetection)
                fp = np.zeros(numberofdetection)

                if BB.shape[0] > 0:
                    # sort by confidence
                    sorted_ind = np.argsort(-confidence)
                    sorted_scores = np.sort(-confidence)
                    BB = BB[sorted_ind, :]
#                    image_ids = [image_ids[x] for x in sorted_ind]

                    # go down dets and mark TPs and FPs
                    for d in range(numberofdetection):    
                        # class_recs: is the : extract gt objects for this class
                        if classname_CheckingNow not in  Classes_With_BBOXES.keys():
                            tp[d] = 0
                            fp[d] = 1
                            
                        else:
#                            print(1)
                            R = Classes_With_BBOXES[classname_CheckingNow] 
                            bb = BB[d, :].astype(float)
                            ovmax = -np.inf
                            
                            if len(R['bbox'])>1:
#                                print(R['bbox'])
                                BBGT = R['bbox'].astype(float)
                            else: 
                                BBGT = R['bbox'].astype(float)
                                
                
                            if BBGT.size > 0:
                                # compute overlaps array([[625, 183, 833, 363]])
                                # intersection
                                ixmin = np.maximum(BBGT[:,0], bb[0])
                                iymin = np.maximum(BBGT[:,1], bb[1])
                                ixmax = np.minimum(BBGT[:,2], bb[2])
                                iymax = np.minimum(BBGT[:,3], bb[3])
                                iw = np.maximum(ixmax - ixmin + 1., 0.)
                                ih = np.maximum(iymax - iymin + 1., 0.)
                                inters = iw * ih
                
                                # union
                                uni = ((bb[2] - bb[0] + 1.) * (bb[3] - bb[1] + 1.) +
                                       (BBGT[:,2] - BBGT[:,0] + 1.) *
                                       (BBGT[:,3] - BBGT[:,1] + 1.) - inters)
                
                                overlaps = inters / uni
                                ovmax = np.max(overlaps)
                                jmax = np.argmax(overlaps)
                                
                                if ovmax > ovthresh:
                                    if not R['det'][jmax]:
                                        tp[d] = 1.
                                        R['det'][jmax] = 1
                                    else:
                                        fp[d] = 1.
                                else:
                                    fp[d] = 1.
                fp = np.cumsum(fp)
                tp = np.cumsum(tp)
                rec = tp / float(npos)
                # avoid divide by zero in case the first detection matches a difficult
                # ground truth
                prec = tp / np.maximum(tp + fp, np.finfo(np.float64).eps)
                ap = vid_ap(rec, prec, use_07_metric)
                if np.isnan(ap):
                    print(ap)
                
                if npos!=0:
                    ImagemAP2.append(ap)
        #                ImagemAP2 = 0
                    ImagemAP.append(ap)
                    NAMEImagemAP.append(classname_CheckingNow)
                    
                if npos==0:
                    if len(Alldetection_forthisClass_forthisImage)!=0:
                        ap = 0
                        ImagemAP2.append(ap)
                        ImagemAP.append(ap)
                        NAMEImagemAP.append(classname_CheckingNow)
                                    
            else:
                if classname_CheckingNow in ClassesinImage.keys():
                    ap = 0.0
                    
                    
                    ImagemAP2.append(ap)
                    ImagemAP.append(ap)
                    NAMEImagemAP.append(classname_CheckingNow)
#        for classname_CheckingNow in  allclasses:
#            if :

    
        if len(ImagemAP2)==0:
            ImagemAP2.append(0.0)
        if len(ImagemAP)==0:
            ImagemAP.append(0.0)
        if np.isnan(np.mean(ImagemAP)):
            print(imagename)
            print(ImagemAP)
            
        LISTALLIMAGE.append([imagename, str(np.mean(ImagemAP)), str(np.mean(ImagemAP2)), ImagemAP, NAMEImagemAP])
        print ("\r{}/{}  ".format(ccc, len(imagenames)), end="")
        
        if np.mean(ImagemAP)>0.5:
            print('wwwooooooooowwww')
#            print(imagename)

        
    with open("LISTALLIMAGE.txt", "w") as f:   #Pickling
        for kk in LISTALLIMAGE:
            f.write('{} {} {}\n'.format(kk[0], kk[1] , kk[2]))

#            f.write('{} {} {} {} {}\n'.format(kk[0], kk[1] , kk[2], kk[3], kk[4] ))
#    pickle.dump(LISTALLIMAGE, fp)
#    for imagename in imagenames:
#                        return rec, prec, ap
