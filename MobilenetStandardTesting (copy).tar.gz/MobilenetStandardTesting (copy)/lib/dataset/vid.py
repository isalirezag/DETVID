import os
import pickle
import os.path
import sys
import torch
import torch.utils.data as data
import torchvision.transforms as transforms
from PIL import Image, ImageDraw, ImageFont
import cv2
import numpy as np
import xml.etree.ElementTree as ET
import sys
from .vid_eval_ali import vid_eval
from .vid_eval_ali_map_image import vid_eval_map
import shutil

VID_CLASSES = ['__background__',  # always index 0
                 'n02691156', 'n02419796', 'n02131653', 'n02834778', 'n01503061',
                 'n02924116', 'n02958343', 'n02402425', 'n02084071', 'n02121808',
                 'n02503517', 'n02118333', 'n02510455', 'n02342885', 'n02374451',
                 'n02129165', 'n01674464', 'n02484322', 'n03790512', 'n02324045',
                 'n02509815', 'n02411705', 'n01726692', 'n02355227', 'n02129604',
                 'n04468005', 'n01662784', 'n04530566', 'n02062744', 'n02391049']


#Mood = 'Train'
Mood = 'Test'
HomeResult = '/home/alireza/MobilenetStandardTesting/Results'
#if os.path.exists(HomeResult):
#    shutil.rmtree (HomeResult)

if Mood == 'Train':
    #f = open('Train_Ann_Frame_Addresses_DET.pckl', 'rb')
    #AllVideoFramesInfo_DET, AllAnnoInfo_DET = pickle.load(f)
    #f.close()


    f = open('Train_Ann_Frame_Addresses_VID.pckl', 'rb')
    AllVideoFramesInfo_VID, AllAnnoInfo_VID = pickle.load(f)
    f.close()

elif Mood == 'Test':
     #f = open('Small_Validation_Ann_Frame_Addresses.pckl', 'rb')
     #AllVideoFramesInfo_VID, AllAnnoInfo_VID = pickle.load(f)
     #f.close()

     f = open('Validation_Ann_Frame_Addresses.pckl', 'rb')
     AllVideoFramesInfo_VID, AllAnnoInfo_VID = pickle.load(f)
     f.close()
    #
    # f = open('Train_Ann_Frame_Addresses_VID.pckl', 'rb')
    # AllVideoFramesInfo_VID, AllAnnoInfo_VID = pickle.load(f)
    # f.close()

def check_bbox(img_path, anno_path):

    tree = ET.parse(anno_path)
    labels = tree.findall('object')

    anno = []
    if labels == []:
        return np.empty((0, 5))
    img = cv2.imread(str(img_path))
    for index, label in enumerate(labels):
        idx_class = label.find('name').text
        idx = VID_CLASSES.index(idx_class)
        bbox = label.find('bndbox')
        x0 = float(bbox.find('xmin').text) + 0
        y0 = float(bbox.find('ymin').text) + 0
        x1 = float(bbox.find('xmax').text) + 0
        y1 = float(bbox.find('ymax').text) + 0

        bbox = cv2.rectangle(img, (int(x0), int(y0)), (int(x1), int(y1)), (0, 255, 0), 3)
        cv2.putText(bbox, idx, (int(x0) - 5, int(y0) - 5),
                    cv2.FONT_HERSHEY_TRIPLEX, 0.75, (0, 255, 0), 1)



    k = cv2.waitKey(250)
    if k == 27:  # If escape was pressed exit
        cv2.destroyAllWindows()
        sys.exit()
    cv2.imshow('Image', img)

    anno.append([x0, y0, x1, y1, idx])

    anno = np.asarray(anno)

    return anno
class AnnotationTransform(object):

    def __init__(self,  anno_path):

        self.anno_path = anno_path
        self.tree = ET.parse(anno_path)

    def __call__(self):
        labels = self.tree.findall('object')
        anno = []
        if labels == []:
            return np.empty((0, 5))

        for index, label in enumerate(labels):

            idx_class = label.find('name').text
            idx = VID_CLASSES.index(idx_class)
            bbox = label.find('bndbox')
            x0 = float(bbox.find('xmin').text) + 0
            y0 = float(bbox.find('ymin').text) + 0
            x1 = float(bbox.find('xmax').text) + 0
            y1 = float(bbox.find('ymax').text) + 0

            anno.append([x0, y0, x1, y1, idx])

        anno = np.asarray(anno)



        return anno  # [[xmin, ymin, xmax, ymax, label_ind], ... ]


class VIDDetection(data.Dataset):

    def __init__(self, pck_file, image_sets, preproc=None):
        self.root =  '/home/alireza/Datasets/ILSVRC2015'
        #if pck_file == 'Train_Ann_Frame_Addresses_VID.pckl':
        with open(pck_file, 'rb') as f:
            imgs_path = pickle.load(f)
        self.imgs_path = imgs_path[0]
        self.labels_path = imgs_path[1]
        self.preproc = preproc


        #self._year =
        self._image_set = 'vid'

        self._classes = ('__background__',  # always index 0
                         'n02691156','n02419796','n02131653','n02834778','n01503061',
                         'n02924116','n02958343', 'n02402425','n02084071','n02121808',
                         'n02503517','n02118333','n02510455','n02342885','n02374451',
                         'n02129165','n01674464','n02484322','n03790512','n02324045',
                         'n02509815','n02411705','n01726692','n02355227','n02129604',
                         'n04468005','n01662784','n04530566','n02062744','n02391049')

       # self._class_to_ind = dict(zip(self._classes, range(self.num_classes)))
        self._image_ext = '.JPEG'

        if self._image_set == 'det':
            self._image_index = AllVideoFramesInfo_DET
        elif self._image_set == 'vid':
            self._image_index = AllVideoFramesInfo_VID
        elif self._image_set == 'vid_test':
            self._image_index = AllVideoFramesInfo_VID
        # Default to roidb handler
        # self._roidb_handler = self.selective_search_roidb

        #self._roidb_handler = self.gt_roidb

       # self._salt = str(uuid.uuid4())
        self._comp_id = 'comp4'

        # PASCAL specific config options
        self.config = {'cleanup': True,
                       'use_salt': True,
                       'use_diff': False,
                       'matlab_eval': False,
                       'rpn_file': None,
                       'min_size': 2}

    def __getitem__(self, index):
        img_path = self.imgs_path[index].strip('\n')
        image = cv2.imread(img_path, cv2.IMREAD_COLOR)
        if image is None:
            raise Exception("Read image error: {}".format(img_path))

        anno_path = self.labels_path[index].strip('\n')
        target_transform = AnnotationTransform(anno_path)
        target = target_transform()

        #img_path = check_bbox(img_path, anno_path)

        if self.preproc is not None:
            image, target = self.preproc(image, target)

        return image, target

    def __len__(self):
        return len(self.imgs_path)


    def _get_comp_id(self):
        self._comp_id
        return self._comp_id

    def pull_image(self, index):
        img_path =  self.imgs_path[index].strip('\n')
        #print(img_path)
        image = cv2.imread(img_path, cv2.IMREAD_COLOR)

        return img_path, image

    def pull_anno(self, index):
        img_path = self.imgs_path[index].strip('\n')

        anno_path = self.labels_path
        target_transform = AnnotationTransform(anno_path)

        anno = target_transform()

        return anno

    # def pull_img_anno(self, index):
    # skip this function first

    def pull_tensor(self, index):
        to_tensor = transforms.ToTensor()
        return torch.Tensor(self.pull_image(index)).unsqueeze_(0)

    #TODO changed to ali's version
    #def evaluate_detections(self, all_boxes, output_dir=None):
     #   self._write_vid_results_file(all_boxes)
      #  aps, map = self._do_python_eval(output_dir)
       # return aps, map

    ####################################################
    def evaluate_detections(self, all_boxes, output_dir):
#        self._write_voc_results_file(all_boxes)
#        self._do_python_eval_ali(output_dir)
        self._do_python_eval_ali_mAP_Image(output_dir)
        # vid_eval_ali_map_image
        if self.config['matlab_eval']:
            self._do_matlab_eval(output_dir)
        if self.config['cleanup']:
            for cls in self._classes:
                if cls == '__background__':
                    continue
                filename = self._get_voc_results_file_template().format(cls)
#                os.remove(filename)

    def _write_voc_results_file(self, all_boxes):
        #what does this function do?
        # for each class in self._classes do _get_voc_results_file_template
        # _get_voc_results_file_template: 
        for cls_ind, cls in enumerate(self._classes):
            if cls == '__background__':
                continue
            print('Writing {} VOC results file'.format(cls))
        # _get_voc_results_file_template: 
            filename = self._get_voc_results_file_template().format(cls)
            filenameALL = '/home/alireza/MobilenetStandardTesting/Results/results/ALLDATA.txt'
#            '/home/alireza/MobilenetStandardTesting/Results/results/comp4_det_vid_{:s}.txt'
#            in other words it makes the txt files for the detection results to be there
            with open(filename, 'wt') as f:
                #                for im_ind, index in enumerate(self.image_index):
                for im_ind, index in enumerate(AllAnnoInfo_VID):
#                    AllAnnoInfo_VID is the whole frames name
                    
                    dets = all_boxes[cls_ind][im_ind]
                    if dets == []:
                        continue
                    # the VOCdevkit expects 1-based indices
                    for k in range(dets.shape[0]):
                        f.write('{:s} {:.3f} {:.1f} {:.1f} {:.1f} {:.1f}\n'.
                                format(index, dets[k, -1],
                                       dets[k, 0] + 1, dets[k, 1] + 1,
                                       dets[k, 2] + 1, dets[k, 3] + 1))
#                        #Added by me
#            with open(filenameALL, 'a') as f:
#
#                for im_ind, index in enumerate(AllAnnoInfo_VID):
#
#                    
#                    dets = all_boxes[cls_ind][im_ind]
#                    if dets == []:
#                        continue
#                    # the VOCdevkit expects 1-based indices
#                    for k in range(dets.shape[0]):
#                        f.write('{:s} {:.3f} {:.1f} {:.1f} {:.1f} {:.1f}\n'.
#                                format(index, dets[k, -1],
#                                       dets[k, 0] + 1, dets[k, 1] + 1,
#                                       dets[k, 2] + 1, dets[k, 3] + 1))
                        

    def _get_voc_results_file_template(self):
        # VOCdevkit/results/VOC2007/Main/<comp_id>_det_test_aeroplane.txt
        filename = self._get_comp_id() + '_det_' + self._image_set + '_{:s}.txt'
        #        filedir = os.path.join(self._devkit_path, 'results', 'VOC' + self._year, 'Main')
        filedir = os.path.join(HomeResult, 'results')

        if not os.path.exists(filedir):
            os.makedirs(filedir)
        path = os.path.join(filedir, filename)
        return path

    def _do_python_eval_ali(self, output_dir='output'):
        #        annopath = os.path.join( self._devkit_path, 'Annotations', '{:s}.xml')
        #        imagesetfile = os.path.join( self._devkit_path, 'ImageSets', 'Main', self._image_set + '.txt')

        annopath = os.path.join('A')
        imagesetfile = os.path.join('A')

        #        cachedir = os.path.join(self._devkit_path, 'annotations_cache')
        cachedir = os.path.join(HomeResult, 'annotations_cache')

        aps = []
        # The PASCAL VOC metric changed in 2010
        use_07_metric = False
        # if int(self._year) < 2010 else False
        print('VOC07 metric? ' + ('Yes' if use_07_metric else 'No'))
        if not os.path.isdir(output_dir):
            os.mkdir(output_dir)
        for i, cls in enumerate(self._classes):
            if cls == '__background__':
                continue
            filename = self._get_voc_results_file_template().format(cls)

            rec, prec, ap = vid_eval(filename, annopath, imagesetfile, AllAnnoInfo_VID,
                                     cls, cachedir,
                                     ovthresh=0.5,
                                     use_07_metric=False)
                   
#            filenameALL = '/home/alireza/MobilenetStandardTesting/Results/results/ALLDATA.txt'
#            rec, prec, ap = vid_eval_N(filenameALL, annopath, imagesetfile, AllAnnoInfo_VID,
#                         cls, cachedir,
#                         ovthresh=0.5,
#                         use_07_metric=False)
            aps += [ap]
            print('AP for {} = {:.4f}'.format(cls, ap))
            with open(os.path.join(output_dir, cls + '_pr.pkl'), 'wb') as f:
                pickle.dump({'rec': rec, 'prec': prec, 'ap': ap}, f)
        print('Mean AP = {:.4f}'.format(np.mean(aps)))
        print('~~~~~~~~')
        print('Results:')
        for ap in aps:
            print('{:.3f}'.format(ap))
        print('{:.3f}'.format(np.mean(aps)))
        print('~~~~~~~~')
        print('')
        print('--------------------------------------------------------------')
        print('Results computed with the **unofficial** Python eval code.')
        print('Results should be very close to the official MATLAB eval code.')
        print('Recompute with `./tools/reval.py --matlab ...` for your paper.')
        print('-- Thanks, The Management')
        print('--------------------------------------------------------------')


    def _do_python_eval_ali_mAP_Image(self, output_dir='output'):
        
        annopath = os.path.join('A')
        imagesetfile = os.path.join('A')

        #        cachedir = os.path.join(self._devkit_path, 'annotations_cache')
        cachedir = os.path.join(HomeResult, 'annotations_cache')

        aps = []
        # The PASCAL VOC metric changed in 2010
        use_07_metric = False
        # if int(self._year) < 2010 else False
        print('VOC07 metric? ' + ('Yes' if use_07_metric else 'No'))
        if not os.path.isdir(output_dir):
            os.mkdir(output_dir)
        ALLCLasses = []
        for i, cls in enumerate(self._classes):
            if cls == '__background__':
                continue
            ALLCLasses.append(cls)
        filename = self._get_voc_results_file_template()#.format(cls)
        
        vid_eval_map(filename, annopath, imagesetfile, AllAnnoInfo_VID,
                                     ALLCLasses, cachedir,
                                     ovthresh=0.5,
                                     use_07_metric=False)
                   
#            filenameALL = '/home/alireza/MobilenetStandardTesting/Results/results/ALLDATA.txt'
#            rec, prec, ap = vid_eval_N(filenameALL, annopath, imagesetfile, AllAnnoInfo_VID,
#                         cls, cachedir,
#                         ovthresh=0.5,
##                         use_07_metric=False)
#            aps += [ap]
#            print('AP for {} = {:.4f}'.format(cls, ap))
#            with open(os.path.join(output_dir, cls + '_pr.pkl'), 'wb') as f:
#                pickle.dump({'rec': rec, 'prec': prec, 'ap': ap}, f)
#        print('Mean AP = {:.4f}'.format(np.mean(aps)))
#        print('~~~~~~~~')
#        print('Results:')
#        for ap in aps:
#            print('{:.3f}'.format(ap))
#        print('{:.3f}'.format(np.mean(aps)))
#        print('~~~~~~~~')
#        print('')
#        print('--------------------------------------------------------------')
#        print('Results computed with the **unofficial** Python eval code.')
#        print('Results should be very close to the official MATLAB eval code.')
#        print('Recompute with `./tools/reval.py --matlab ...` for your paper.')
#        print('-- Thanks, The Management')
#        print('--------------------------------------------------------------')



    def _get_autel_results_file_template(self):
        filename = 'comp4_det_test' + '_{:s}.txt'
        filedir = os.path.join(
            self.root, 'results', 'VID')
        if not os.path.exists(filedir):
            os.makedirs(filedir)
        path = os.path.join(filedir, filename)
        return path

    def _write_vid_results_file(self, all_boxes):
        for cls_ind, cls in enumerate(VID_CLASSES):
            cls_ind = cls_ind 

            if cls == '__background__':
                continue

            print('Writing {} VID results file'.format(cls))
            filename = self._get_autel_results_file_template().format(cls)
            with open(filename, 'wt') as f:
                for im_ind, img_path in enumerate(self.imgs_path):
                    index = img_path.strip('\n').split('/')[-1].split('.')[0] # just the image name

                    dets = all_boxes[cls_ind][im_ind]
                    if dets == []:
                        continue
                    for k in range(dets.shape[0]):
                        f.write('{:s} {:.3f} {:.1f} {:.1f} {:.1f} {:.1f}\n'.
                                format(index, dets[k, -1],
                                dets[k, 0] + 1, dets[k, 1] + 1,
                                dets[k, 2] + 1, dets[k, 3] + 1))

    def _do_python_eval(self, output_dir='output'):
        rootpath = '/home/alireza/Datasets/ILSVRC2015'
        annopath = os.path.join(rootpath, 'Annotations', 'VID','val','*', '{:s}.xml' )
       # imagesetfile = os.path.join(rootpath, 'autel.txt')
        imagesetfile = self.imgs_path
        cachedir = os.path.join(self.root, 'annotations_cache')

        aps = []

        if output_dir is not None and not os.path.isdir(output_dir):
            os.mkdir(output_dir)

        for i, cls in enumerate(VID_CLASSES):

            if cls == '__background__':
                continue

            filename = self._get_autel_results_file_template().format(cls)

            print(filename)
            rec, prec, ap = vid_eval(
                                    filename, annopath, imagesetfile, cls, cachedir, ovthresh=0.5)

            aps += [ap]
            print('AP for {} = {:.4f}'.format(cls, ap))
            if output_dir is not None:
                with open(os.path.join(output_dir, cls + '_pr.pkl'), 'wb') as f:
                    pickle.dump({'rec': rec, 'prec': prec, 'ap': ap}, f)
        print('Mean AP = {:.4f}'.format(np.mean(aps)))
        print('~~~~~~~~')
        print('Results:')
        for ap in aps:
            print('{:.3f}'.format(ap))
        print('{:.3f}'.format(np.mean(aps)))
        print('~~~~~~~~')
        print('')
        print('--------------------------------------------------------------')
        print('Results computed with the **unofficial** Python eval code.')
        print('Results should be very close to the official MATLAB eval code.')
        print('Recompute with `./tools/reval.py --matlab ...` for your paper.')
        print('-- Thanks, The Management')
        print('--------------------------------------------------------------')
        return aps,np.mean(aps)


    def show(self, index):
        img, target = self.__getitem__(index)
        for obj in target:
            obj = obj.astype(np.int)
            cv2.rectangle(img, (obj[0], obj[1]), (obj[2], obj[3]), (255,0,0), 3)
        cv2.imwrite('./image.jpg', img)


## test
# if __name__ == '__main__':
#     ds = VOCDetection('../../../../../dataset/VOCdevkit/', [('2012', 'train')],
#             None, AnnotationTransform())
#     print(len(ds))
#     img, target = ds[0]
#     print(target)
#     ds.show(1)
