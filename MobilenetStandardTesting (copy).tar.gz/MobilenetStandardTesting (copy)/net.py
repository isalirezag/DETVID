import torch
import torch.nn as nn
import torch.utils.model_zoo as model_zoo
from torch.autograd import Variable
import torch.nn.functional as F
import numpy as np
import matplotlib.pyplot as plt
import time


class Prediction(nn.Module):

    def __init__(self):
        super(Prediction, self).__init__()
        self.base = self.VGG16()
        self.full = self.Fully(Features = 2)
        


    def forward(self, x):
        
        for i, name in enumerate(self.base):
            x = self.base[i](x)
        x = x.view(x.size(0),-1)
        x = self.full[0](x)
        x = self.full[1](x)
        x = self.full[2](x)
        x = self.full[3](x)
        x = self.full[4](x)

        return x

    def VGG16(self):

        cfg = [64, 64, 'M', 128, 128, 'M', 256, 256, 256, 'M', 512, 512, 512, 'M', 512, 512, 512, 'M']

        layers = nn.ModuleList()
        in_channels = 3
        for x in cfg:
            if x == 'M':
                layers.append(nn.MaxPool2d(kernel_size=2, stride=2, ceil_mode=True))
            else:
                layers.append(nn.Conv2d(in_channels, x, kernel_size=3, padding=1))
                layers.append(nn.BatchNorm2d(x,affine=False))
#                layers.append(nn.GroupNorm(x, x, affine=False))
                layers.append(nn.ReLU(True))
                in_channels = x
        return layers

    def Fully(self, Features = 2):

        prediction = nn.ModuleList()
        
        prediction.append(nn.Linear(51200, 4096))
        prediction.append(nn.ReLU(True))
        prediction.append(nn.Linear(4096, 4096))
        prediction.append(nn.ReLU(True))
        prediction.append(nn.Linear(4096, Features))


        return prediction

if __name__ == '__main__':
    A = Variable(torch.rand(4,3,300,300))
    AA = Prediction()
#    bo, jo, ko =AA(A)
    bo  =AA(A)
    print(bo.size())
#    print(jo.size())
#    print(ko.size())
