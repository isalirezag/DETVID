import torch
import torch.utils.data as data
import os.path
import numpy as np
import numpy as np
import torch.utils.data as data

from torch.autograd import Variable
import  torch
import torch.nn as nn
import torch.optim as optim
import time
import random
import numpy as np
import matplotlib.pyplot as plt
import os
import cv2
import matplotlib.pyplot as plt
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np
import random
import matplotlib.pyplot as plt
import cv2
from PIL import Image
import numpy as np
NotGood = list(np.load('NotGood.npy'))
Good = list(np.load('Good.npy'))
All = list(np.load('All.npy'))


def detection_collate_(batch):
    

    Names = []
    Namesa = []
    
    imgout = []
    
#    print('agsagd',batch)
#    print('typetype',type(batch))
#    print('typetype',len(batch))
#    print('adgadhg',batch[0])
#    print('adgadhg',batch[1])
#    
    for ii in range(len(batch)):
#        print('iiiiiiiii',ii)
#        print('gdgsd',batch[ii])
        Names.append(batch[ii])
#        print('NamesNames',Names)
        
        img = mpimg.imread(batch[ii])
        resized_image = cv2.resize(img, (300, 300)) 
        resized_image = resized_image/255.
        NewTorch = torch.from_numpy(resized_image)
        NewTorch = NewTorch.permute(2,0,1).contiguous()
        

        imgout.append(NewTorch)
#        print(NewTorch.shape)
    
    return (Names , torch.stack(imgout, 0))



class Dataset_classifying(data.Dataset):

    def __init__(self, Data):

        self.AllDataInf = Data

    def __getitem__(self, index):

        return self.AllDataInf[index]

    def __len__(self):
        return len(self.AllDataInf)
    
    
    



# =============================================================================
# ### Loss and optimizer ###
# =============================================================================
criterion = nn.CrossEntropyLoss()
criterion2 = nn.L1Loss()


#optimizer = optim.SGD(Model.parameters(), lr=0.001, momentum=0.9, weight_decay=5e-4)


Alld = Dataset_classifying(All)


custom_dataset = data.DataLoader(Alld, batch_size = 8, collate_fn=detection_collate_, num_workers = 0,
                                 shuffle = True, pin_memory = True)

#batch_iterator = iter(custom_dataset)
#
#Name , imgs = next(batch_iterator)


print('Each iteration will take {} iter' .format(len(custom_dataset)))

from net import Prediction

Model = Prediction()
Model.cuda()

#optimizer = torch.optim.Adam(Model.parameters(), lr=0.0002, betas=(0.9, 0.999))
optimizer = optim.SGD(Model.parameters(), lr=0.001, momentum=0.9, weight_decay=5e-4)

Img_ = Variable(torch.FloatTensor(1)).cuda()
lll = Variable(torch.LongTensor(1)).cuda()

for epoch in range(100):
    Model.train()



    old_state_dict = {}
    for key in Model.state_dict():
        old_state_dict[key] = Model.state_dict()[key].clone()

    SumLoss = 0

    ReadyForItrationInEpoch = iter(custom_dataset)

    # =============================================================================
    #     # warming up #
    # =============================================================================
    if epoch > 1 and epoch%3==0:
        optimizer.param_groups[0]['lr'] = optimizer.param_groups[0]['lr'] * 0.98
    print('lr {}' .format(optimizer.param_groups[0]['lr']))

    for _ in range(0, len(ReadyForItrationInEpoch)):

        Name, imgs = next(ReadyForItrationInEpoch)

        # zero the parameter gradients
        optimizer.zero_grad()
        Model.zero_grad()


        # =============================================================================
        #         Preprocessing stuff
        # =============================================================================

#        Img = Img.float()

#        targets2 = Variable(torch.LongTensor(len(Name)).random_(2)).cuda()
        label = []
        for k in Name:
            if k in NotGood:
                label.append(0.)
            else:
                label.append(1.)
                
        llabel = torch.from_numpy(np.asarray(label)).cuda()
        # =============================================================================
        #         Training: sending the image to model
        # =============================================================================

        Img_.data.resize_(imgs.size()).copy_(imgs)
        lll.data.resize_(llabel.size()).copy_(llabel)

        predictions =Model( Img_)
        loss_score = criterion(predictions, lll)
 

        loss = loss_score 

        SumLoss += loss.data[0]

        loss.backward()
        optimizer.step()

        print ("\r{}/{} epoch {}/{} Training... {}".format(epoch, 100, _, len(ReadyForItrationInEpoch), loss.data[0]), end="")



    SaveModel= 'Save_Model_Epoch_' + str(epoch) + '.pth'

    torch.save(Model.state_dict(), SaveModel)
    
    print('Average Loss {}' .format(SumLoss/len(ReadyForItrationInEpoch)))

##    
## =============================================================================
## Testing on LIVE
## =============================================================================
#
#
#    correct = 0
#    total = 0
#
#    Scores_L = []
#    Scores_P = []
#
#    Dict_Score_LIVE = {}
#    Dict_Lable_LIVE = {}
#
##    with torch.no_grad():
#    Model.eval()
#
#    custom_datasettest = data.DataLoader(Alld, batch_size = 1, collate_fn=detection_collate_, num_workers = 0,
#                                     shuffle = True, pin_memory = True)
##ReadyForItrationInEpoch
#    batch_iteratortest = iter(custom_datasettest)
#    for DataInTuple in range(len(batch_iteratortest)):
#        Name ,Img  = next(batch_iteratortest)
##        next(ReadyForItrationInEpoch)
#        
##        Name ,Img   = DataInTuple
#        Img = Img.float()
#        Img_.data.resize_(Img.size()).copy_(Img)
#        
#        output_score = Model(Img_)
#
#
#        _, predicted = torch.max(output_score.data, 1)
#        label = []
#        
#        if Name in NotGood:
#            label.append(0.)
#        else:
#            label.append(1.)
#                
#        llabel = torch.from_numpy(np.asarray(label)).cuda().float()
#
#
#
#        total += llabel.size(0)
#        correct += (predicted.float() == llabel).sum() 
#
#
#    print("\n")
#    print('Accuracy of the network on LIVE  on the {} test images: {}' .format(len(batch_iteratortest), 100 * correct / total))
##     
#        
