from __future__ import print_function
import numpy as np
import os
import sys
import cv2
import random
import pickle
import argparse

import torch
import torch.backends.cudnn as cudnn
from torch.autograd import Variable
import torch.optim as optim
from torch.optim import lr_scheduler
import torch.utils.data as data
import torch.nn.init as init

import glob, os, os.path

from lib.utils.config_parse import cfg_from_file

from lib.layers import *
from lib.utils.timer import Timer
from lib.utils.data_augment import preproc
from lib.dataset.dataset_factory import load_data
from lib.utils.config_parse import cfg
from lib.utils.eval_utils import *
from lib.utils.visualize_utils import *
from lib.layers.functions.prior_box import PriorBox
from lib.modeling.mobilenetv1_ssd import MobileNetv1_SSD

HomeDir =  '/home/alireza/MobilenetStandardTesting'

def parse_args():
    """
    Parse input arguments
    """
    parser = argparse.ArgumentParser(description='Train a ssds.pytorch network')
    parser.add_argument('--cfg', dest='config_file',
            help='optional config file', default=None, type=str)

    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)

    args = parser.parse_args()
    return args


def weights_init(m):
    for key in m.state_dict():
        if key.split('.')[-1] == 'weight':
            if 'conv' in key:
                init.kaiming_normal(m.state_dict()[key], mode='fan_out')
            if 'bn' in key:
                m.state_dict()[key][...] = 1
        elif key.split('.')[-1] == 'bias':
            m.state_dict()[key][...] = 0


def initialize(checkpoint):
        # TODO: ADD INIT ways
        # raise ValueError("Fan in and fan out can not be computed for tensor with less than 2 dimensions")
        # for module in self.cfg.TRAIN.TRAINABLE_SCOPE.split(','):
        #     if hasattr(self.model, module):
        #         getattr(self.model, module).apply(self.weights_init)
    if checkpoint:
        print('Loading initial model weights from {:s}'.format(checkpoint))
        resume_checkpoint(checkpoint)

    start_epoch = 0
    return start_epoch

def trainable_param(model, trainable_scope):
    for param in model.parameters():
        param.requires_grad = True

    trainable_param = []
    for module in trainable_scope.split(','):
        if hasattr(model, module):
            # print(getattr(self.model, module))
            for param in getattr(model, module).parameters():
                param.requires_grad = True
            trainable_param.extend(getattr(model, module).parameters())

    return trainable_param



def configure_lr_scheduler(optimizer, cfg):
    if cfg.SCHEDULER == 'step':
        scheduler = lr_scheduler.StepLR(optimizer, step_size=cfg.STEPS[0], gamma=cfg.GAMMA)
    elif cfg.SCHEDULER == 'multi_step':
        scheduler = lr_scheduler.MultiStepLR(optimizer, milestones=cfg.STEPS, gamma=cfg.GAMMA)
    elif cfg.SCHEDULER == 'exponential':
        scheduler = lr_scheduler.ExponentialLR(optimizer, gamma=cfg.GAMMA)
    elif cfg.SCHEDULER == 'SGDR':
        scheduler = lr_scheduler.CosineAnnealingLR(optimizer, T_max=cfg.MAX_EPOCHS)
    else:
        AssertionError('scheduler can not be recognized.')
    return scheduler

def configure_optimizer(trainable_param, cfg):
    if cfg.OPTIMIZER == 'sgd':
        optimizer = optim.SGD(trainable_param, lr=cfg.LEARNING_RATE,
                    momentum=cfg.MOMENTUM, weight_decay=cfg.WEIGHT_DECAY)
    elif cfg.OPTIMIZER == 'rmsprop':
        optimizer = optim.RMSprop(trainable_param, lr=cfg.LEARNING_RATE,
                    momentum=cfg.MOMENTUM, alpha=cfg.MOMENTUM_2, eps=cfg.EPS, weight_decay=cfg.WEIGHT_DECAY)
    elif cfg.OPTIMIZER == 'adam':
        optimizer = optim.Adam(trainable_param, lr=cfg.LEARNING_RATE,
                    betas=(cfg.MOMENTUM, cfg.MOMENTUM_2), eps=cfg.EPS, weight_decay=cfg.WEIGHT_DECAY)
    else:
        AssertionError('optimizer can not be recognized.')
    return optimizer


def _forward_features_size(model, img_size):
    model.eval()
    x = torch.rand(1, 3, img_size[0], img_size[1])
    x = torch.autograd.Variable(x, volatile=True).cuda()
    feature_maps = model(x=x, phase='feature')
    return [(o.size()[2], o.size()[3]) for o in feature_maps]

def eval():
    args = parse_args()
    if args.config_file is not None:
        cfg_from_file(args.config_file)

    output_dir = cfg.EXP_DIR
    RESUME_SCOPE = 'base,norm,extras,loc,conf,bias'
    checkpoint = cfg.RESUME_CHECKPOINT
    max_epochs = cfg.TRAIN.MAX_EPOCHS
    checkpoint_prefix = cfg.CHECKPOINTS_PREFIX
    num_classes = cfg.MODEL.NUM_CLASSES
    feature_layer = cfg.MODEL.FEATURE_LAYER

    model = MobileNetv1_SSD(num_classes, feature_layer)
    filelisttoremove = glob.glob(os.path.join('./Saved/', '*.pkl'))
    for f in filelisttoremove:
        os.remove(f)
#    TrainedModel = torch.load('./Saved/ssd_mobilenet_v1_vid_epoch_299.pth')

    # TrainedModel = torch.load('./experiments/models/ssd_mobilenet_v1_vid/ssd_mobilenet_v1_vid_epoch_299.pth')
    TrainedModel = torch.load('./experiments/models/ssd_mobilenet_v1_vid/ssd_mobilenet_v1_vid+det_epoch_187_.pth')
    model.load_state_dict(TrainedModel)

    feature_maps = _forward_features_size(model, cfg.MODEL.IMAGE_SIZE)
    priorbox = PriorBox(image_size=cfg.MODEL.IMAGE_SIZE, feature_maps=feature_maps, aspect_ratios=cfg.MODEL.ASPECT_RATIOS,
                    scale=cfg.MODEL.SIZES, archor_stride=cfg.MODEL.STEPS, clip=cfg.MODEL.CLIP)
    priors = Variable(priorbox.forward(), volatile=True)

    detector = Detect(cfg.POST_PROCESS, priors)

    if torch.cuda.is_available():
        print('Utilize GPUs for computation')
        print('Number of GPU available', torch.cuda.device_count())
#        if torch.cuda.device_count() > 1:
#            model = torch.nn.DataParallel(model)
        model.cuda()
        priors.cuda()
        cudnn.benchmark = True

    data_loader = load_data(cfg.DATASET, 'test') if 'test' in cfg.PHASE else None


    model.eval()
    output_dir = os.path.join(HomeDir,'./Saved/')
    if not os.path.exists(output_dir):
        os.mkdir(output_dir)
    wt_pth = os.path.join(HomeDir,'./Saved/detections/')


    dataset = data_loader.dataset
    num_images = len(dataset)
    #print('num:', num_images)
    num_classes = detector.num_classes
    all_boxes = [[[] for _ in range(num_images)] for _ in range(num_classes)]
    empty_array = np.transpose(np.array([[],[],[],[],[]]),(1,0))

    _t = Timer()
    #TODO:changed num_images
    for i in iter(range((num_images))):
        img_path, img = dataset.pull_image(i)

        save_n = wt_pth + img_path.split('/')[-1]

        #print(img_path)
        if img is None:
            print('Number: ', i)
            continue
        scale = [img.shape[1], img.shape[0], img.shape[1], img.shape[0]]
        if torch.cuda.is_available():
            images = Variable(dataset.preproc(img)[0].unsqueeze(0).cuda(), volatile=True)
        else:
            images = Variable(dataset.preproc(img)[0].unsqueeze(0), volatile=True)

        _t.tic()
        #print(images.shape)

        # forward
        out = model(images, phase='eval')
        #print(out)

        # detect
        detections = detector.forward(out)
        #print(detections[0,0,:,:])

        time = _t.toc()

        # TODO: make it smart:
        for j in range(1, num_classes):
            cls_dets = list()
            for det in detections[0][j]:
                if det[0] > 0:
                    #print(j)
                    d = det.cpu().numpy()
                    score, box = d[0], d[1:]
                    box *= scale
                    box = np.append(box, score)
                    cls_dets.append(box)
            if len(cls_dets) == 0:
                #print(j)
                cls_dets = empty_array
            all_boxes[j][i] = np.array(cls_dets)

#        cv2.imwrite(save_n, img)
        #print(all_boxes[0])

        # log per iter
        log = '\r==>Test: || {iters:d}/{epoch_size:d} in {time:.3f}s [{prograss}]\r'.format(
                prograss='#'*int(round(10*i/num_images)) + '-'*int(round(10*(1-i/num_images))), iters=i, epoch_size=num_images,
                time=time)
        sys.stdout.write(log)
        sys.stdout.flush()

    # write result to pkl
    with open(os.path.join(output_dir, 'detections.pkl'), 'wb') as f:
        pickle.dump(all_boxes, f, pickle.HIGHEST_PROTOCOL)

    # currently the COCO dataset do not return the mean ap or ap 0.5:0.95 values
    print('Evaluating detections')
    data_loader.dataset.evaluate_detections(all_boxes, output_dir)

if __name__ == '__main__':
    eval()
