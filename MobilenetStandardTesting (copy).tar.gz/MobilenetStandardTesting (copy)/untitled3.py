detfile = '/home/alireza/MobilenetStandardTesting/Results/results/ALLDATA.txt'
with open(detfile, 'r') as f:
    lines = f.readlines()
ALLD = {}
for iii in lines:
    if iii.split()[0] in ALLD:
        ALLD[iii.split()[0]].append(iii.split()[1:])
    else:
        ALLD[iii.split()[0]] = []
        ALLD[iii.split()[0]].append(iii.split()[1:])

