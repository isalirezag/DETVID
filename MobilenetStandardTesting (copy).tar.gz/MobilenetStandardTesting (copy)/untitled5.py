#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr  8 18:55:29 2019

@author: alireza
"""

ff= ['/home/alireza/Datasets/ILSVRC2015/Data/VID/val/ILSVRC2015_val_00016010/000428.JPEG', '/home/alireza/Datasets/ILSVRC2015/Data/VID/val/ILSVRC2015_val_00170002/000113.JPEG', '/home/alireza/Datasets/ILSVRC2015/Data/VID/val/ILSVRC2015_val_00021001/000313.JPEG']
for i,j in enumerate(ff):
    print(i,j)
    