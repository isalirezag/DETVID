import pickle
import xml.etree.ElementTree as ET
import os
HOME2 = os.getcwd()
#'/home/alupotto/data/ILSVRC2015/Annotations/VID/train/'
#AnnotationPath = '/home/alireza/Desktop/Datasets/VID/ILSVRC-Old/Annotations/val/'
AnnotationPath = '/home/alireza/Datasets/ILSVRC2015/Annotations/VID/val/'

AllAnnotations= os.listdir (AnnotationPath) # get all files' and folders' names in the current directory
AllAnnotations.sort() # These are all the video files inside
#print(AllAnnotations)

VideoAnnsNames = []
for VideoName in AllAnnotations[:]: # loop through all the files and folders
    if os.path.isdir(os.path.join(os.path.abspath(AnnotationPath), VideoName)): # check whether the current object is a folder or not,meaning if there is frames inside the currentvideo folder or not
        VideoAnnsNames.append(os.path.join(os.path.abspath(AnnotationPath), VideoName))

VideoAnnsNames.sort()

AnnsVideosAndFrames = {}
AllAnnoInfo = []
AllVideoFramesInfo = []
for index, Video in enumerate(VideoAnnsNames[:]):
    Annotation = os.listdir(Video + '/')
    Annotation.sort()
    AnnsVideosAndFrames[Video] = Annotation


    print('index: {}' .format(index))
    for annotation_ii in Annotation:
        AnnAddress = Video + '/' + annotation_ii
        FrameAddress = Video.split('/')
        FrameAddress[FrameAddress.index('Annotations')] = 'Data'
        FrameAddressUpdate = os.path.join('/'.join(FrameAddress),annotation_ii[:-3] + 'JPEG')


        tree = ET.parse(AnnAddress).getroot()
        EXIST = any(True for _ in tree.iter('object'))
#        if not EXIST:
#            print(AnnAddress)
        if EXIST or not EXIST:

#            for sizes in tree.iter('size'):
#                W = float(sizes.find('width').text)
#                H = float(sizes.find('height').text)
#
#            objs = tree.findall('object')
#            x1, y1, x2, y2 = [], [], [], []
#             # Load object bounding boxes into a data frame.
#            for ix, obj in enumerate(objs):
#                bbox = obj.find('bndbox')
#                x2.append(float(bbox.find('xmax').text))
#                y2.append(float(bbox.find('ymax').text))
#                y1.append(float(bbox.find('ymin').text))
#                x1.append(float(bbox.find('xmin').text))
#            if max(x2)<=W and max(y2)<=H and min(x1)>=0 and min(y1)>=0:
                AllAnnoInfo.append(AnnAddress)
                AllVideoFramesInfo.append(FrameAddressUpdate)


print('Number of images is : {}' .format(len(AllAnnoInfo)))
##Out[37]: 1122397
#176126/172080/172080
# =============================================================================
 # Saving the objects:
f = open('Validation_Ann_Frame_Addresses.pckl', 'wb')
pickle.dump([AllVideoFramesInfo, AllAnnoInfo], f)
f.close()
#
# # Getting back the objects:
# f = open('Ann_Frame_Addresses.pckl', 'rb')
# AllVideoFramesInfo, AllAnnoInfo = pickle.load(f)
# f.close()
# =============================================================================
