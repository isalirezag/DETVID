import numpy as np
import matplotlib.pyplot as plt
f = open('/home/alireza/Desktop/MobileNet/MobilenetStandardTesting/Results/results/All.txt', 'r')
#f = open('/home/alireza/Desktop/MobileNet/MobilenetStandardTesting/Results/results/comp4_det_vid_n02084071.txt', 'r')
textfile = f.readlines()
f.close()

#%matplotlib auto


count = 0

L = []
Value = []
Value2 = []
Good = []
Bad = []

for i in textfile:
#    print(i)
    stextfile =i.split()
#    print(1)
    count += 1
    L.append( stextfile[0].replace('Annotations','Data').replace('xml','JPEG'))
    Value.append(float(stextfile[1]))
    
#plt.plot(Value)
#plt.show()


col_vec = np.array(Value, ndmin=1)
hist, bin_edges = np.histogram(col_vec, density=False)
print(bin_edges)
print(hist)
plt.hist(col_vec, bins='auto')  # arguments are passed to np.histogram
plt.title("Histogram with 'auto' bins")
plt.show()


for i in textfile:
#    print(i)
    stextfile =i.split()
#    print(1)

#    L.append( stextfile[0].replace('Annotations','Data').replace('xml','JPEG'))
#    Value2.append(float(stextfile[1]))
    
    if float(stextfile[1])>0.8 :

        Good.append(stextfile[0].replace('Annotations','Data').replace('xml','JPEG'))
    
    
    if float(stextfile[1])<0.1:
        Bad.append(stextfile[0].replace('Annotations','Data').replace('xml','JPEG'))
        
BadBad = list(set(Bad))
            
Goodd = list(set(Good))
    
#    /home/alireza/Datasets/ILSVRC2015/Data/VID/val/ILSVRC2015_val_00007038/000101.JPEG

Not = list(set(BadBad)-set(Goodd))

np.save('NotGood', Not)
np.save('Good', Goodd)
np.save('All', Not + Goodd)

#%%
#%pylab auto

#%matplotlib auto
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
img=mpimg.imread(Not[2281])
imgplot = plt.imshow(img)
plt.show()
