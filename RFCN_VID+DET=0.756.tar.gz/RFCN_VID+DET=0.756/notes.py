alireza@light2a:~/RFCN$ python trainval_net.py  --arch rfcn --dataset vid --net res101 --nw 4   --cuda --mGPUs --bs 8 --r True --checksession 1 --checkepoch 10 --checkpoint 56849

# ########################################
alireza@light2a:~/RFCN$ python trainval_net.py  --arch rfcn --dataset vid --net res101 --nw 4  --lr 4e-3 --lr_decay_step 5 --cuda --mGPUs --bs 8
Called with args:
Namespace(arch='rfcn', batch_size=8, checkepoch=1, checkpoint=0, checkpoint_interval=10000, checksession=1, class_agnostic=False, cuda=True, dataset='vid', disp_interval=100, large_scale=False, lr=0.004, lr_decay_gamma=0.1, lr_decay_step=5, mGPUs=True, max_epochs=100, net='res101', num_workers=4, ohem=False, optimizer='sgd', resume=False, save_dir='save', session=2, start_epoch=1, use_tfboard=False)
<datasets.pascal_vid.pascal_vid object at 0x7f96a58a2f60>
Loaded dataset `vid_0000_vid_test` for training
Set proposal method: gt
Appending horizontally-flipped training examples...

wrote gt roidb to /home/alireza/RFCN/data/cache/vid_0000_vid_test_gt_roidb.pkl
done
Preparing training data...
done
<datasets.pascal_vid.pascal_vid object at 0x7fa944d4a8d0>
before filtering, there are 240646 images...
after filtering, there are 240646 images...
240646 roidb entries
Loading pretrained weights from data/pretrained_model/resnet101_rcnn.pth
Alireza 0.004
Alireza2 0.004
Alireza3 0.004
Alireza4 0.004
[session 2][epoch 1][iter 0/30080] loss:4.406, lr: 0.004, [fg/bg=(82/942)], time cost: 15.39, trpn_cls: 0.72244, rpn_box: 0.051861, rcnn_cls: 3.4379, rcnn_box  0.19427
# ########################################
