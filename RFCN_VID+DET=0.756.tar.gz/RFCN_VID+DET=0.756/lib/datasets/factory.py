# --------------------------------------------------------
# Fast R-CNN
# Copyright (c) 2015 Microsoft
# Licensed under The MIT License [see LICENSE for details]
# Written by Ross Girshick
# --------------------------------------------------------

"""Factory method for easily getting imdbs by name."""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

__sets = {}

from datasets.pascal_vid import pascal_vid
#from datasets.pascal_vid_temporal import pascal_vid_temporal

import numpy as np






#for _ in ['vid+det', 'vid_test']:
for _ in ['vid+det']:
    year = '0000'
    split = ' '
    __sets['vid'] = (lambda split=split, year=year: pascal_vid('vid',year))
    __sets['det'] = (lambda split=split, year=year: pascal_vid('det',year))
    __sets['vid_test'] = (lambda split=split, year=year: pascal_vid('vid_test',year))
##
##for _ in ['vid']:
##    year = '0000'
##    split = ' '
##    __sets['vid'] = (lambda split=split, year=year: pascal_vid('vid',year))
##    __sets['vid_test'] = (lambda split=split, year=year: pascal_vid('vid_test',year))
#
#for _ in ['det']:
#    year = '0000'
#    split = ' '
#    __sets['det'] = (lambda split=split, year=year: pascal_vid('det',year))
#    __sets['vid_test'] = (lambda split=split, year=year: pascal_vid('vid_test',year))


#for NAME in ['vid', 'vid_test']:
#    year = '0000'
#    split = ' '
#    __sets[NAME] = (lambda split=split, year=year: pascal_vid(NAME,year))


#for NAME in ['vid_temporal', 'vid_temporal_test']:
#    year = '0000'
#    split = ' '
#    __sets[NAME] = (lambda split=split, year=year: pascal_vid_temporal(NAME,year))

# =============================================================================
# for year in ['2007', '2012']:
#   for split in ['train', 'val', 'trainval', 'test']:
#     name = 'voc_{}_{}'.format(year, split)
#     __sets[name] = (lambda split=split, year=year: pascal_voc(split, year))
#     
# for year in ['2015']:
#     for split in ['vid', 'vid_test']:
#         name = 'vid_{}_{}'.format(year, split)
#         __sets[name] = (lambda split=split, year=year: pascal_vid(name,year))
# =============================================================================


def get_imdb(name):
  """Get an imdb (image database) by name."""
  if name not in __sets:
    raise KeyError('Unknown dataset: {}'.format(name))
  print(__sets[name]())
  return __sets[name]()


def list_imdbs():
  """List all registered imdbs."""
  return list(__sets.keys())
