import os
import pickle
import numpy as np
import xml.etree.ElementTree as ET


ClassesToNames = {
'n02691156':'airplane',
'n02419796':'antelope',
'n02131653':'bear',
'n02834778':'bicycle',
'n01503061':'bird',
'n02924116':'bus',
'n02958343':'car',
'n02402425':'cattle',
'n02084071':'dog',
'n02121808':'domestic cat',
'n02503517':'elephant',
'n02118333':'fox',
'n02510455':'giant panda',
'n02342885':'hamster',
'n02374451':'horse',
'n02129165':'lion',
'n01674464':'lizard',
'n02484322':'monkey',
'n03790512':'motorcycle',
'n02324045':'rabbit',
'n02509815':'red panda',
'n02411705':'sheep',
'n01726692':'snake',
'n02355227':'squirrel',
'n02129604':'tiger',
'n04468005':'train',
'n01662784':'turtle',
'n04530566':'watercraft',
'n02062744':'whale',
'n02391049':'zebra'}

VID = ('n02691156','n02419796','n02131653','n02834778','n01503061',
       'n02924116','n02958343', 'n02402425','n02084071','n02121808',
       'n02503517','n02118333','n02510455','n02342885','n02374451',
       'n02129165','n01674464','n02484322','n03790512','n02324045',
       'n02509815','n02411705','n01726692','n02355227','n02129604',
       'n04468005','n01662784','n04530566','n02062744','n02391049')

VIDLAVLES = dict(zip(VID, range(len(VID))))


# Getting back the objects:
f = open('Train_Ann_Frame_Addresses.pckl', 'rb')
AllVideoFramesInfo, AllAnnoInfo = pickle.load(f)
f.close()

#%%
# We have 30 classes in a dictionary
# in each time we read all the annotations and add +1 to that class and save the
# index of that file in another list

print('All the files:',len(AllAnnoInfo))

Labling = {}
LablingListsAnn = {}
LablingListsFrame = {}
for indexx, NameAddress in enumerate(AllAnnoInfo):
#    print(i)
    tree = ET.parse(NameAddress).getroot()
    EXIST = any(True for _ in tree.iter('object'))
    for obj in tree.iter('object'):
        label = obj.find('name').text.lower().strip()
#        print(Labling)
        NAME = ClassesToNames[label]
        if NAME in Labling:
            Labling[NAME] = 1 + Labling.get(NAME, 0)

            LablingListsAnn[NAME].append(AllAnnoInfo[indexx])
            LablingListsFrame[NAME].append(AllVideoFramesInfo[indexx])
        else:
            Labling[NAME] = 1
            LablingListsAnn[NAME] = list()
            LablingListsAnn[NAME].append(AllAnnoInfo[indexx])



            LablingListsFrame[NAME] = list()
            LablingListsFrame[NAME].append(AllVideoFramesInfo[indexx])

#print(sorted(Labling.items(), key=lambda k:k[1] ))

#%%
AllAnnoInfoNew = []
AllVideoFramesInfoNew = []
C = 0
Percent = 5/100.0
for I in Labling:
#    print(I)
    A = max(round(Percent * Labling[I]),1)


    print(A)
    C += A
    arr = np.arange(Labling[I])
    np.random.shuffle(arr)
    B = arr[:A]
#    print(len(B), Labling[I])
    for J in B:
        if LablingListsAnn[I][J] not in AllAnnoInfoNew:
            AllAnnoInfoNew.append(LablingListsAnn[I][J])
            AllVideoFramesInfoNew.append(LablingListsFrame[I][J])


print(len(AllAnnoInfoNew))
AllAnnoInfoNew2 = list(set(AllAnnoInfoNew))
#AllVideoFramesInfoNew2 = list(set(AllVideoFramesInfoNew))
print(len(AllAnnoInfoNew2))

# # Saving the objects:
f = open('Small_Training_Ann_Frame_Addresses.pckl', 'wb')
pickle.dump([AllVideoFramesInfoNew, AllAnnoInfoNew], f)
f.close()
