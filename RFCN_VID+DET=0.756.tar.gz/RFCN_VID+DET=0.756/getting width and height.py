import xml.etree.ElementTree as ET

filename = '/home/alireza/Desktop/Datasets/VID/ILSVRC-Old/Annotations/train/ILSVRC2015_train_01105000/000293.xml'
tree = ET.parse(filename).getroot()



for obj in tree.iter('size'):

    W = float(obj.find('width').text)
    H = float(obj.find('height').text)

objs = tree.findall('object')
x2, y2 = [], []
# Load object bounding boxes into a data frame.
for ix, obj in enumerate(objs):
    bbox = obj.find('bndbox')
    x2.append(float(bbox.find('xmax').text))
    y2.append(float(bbox.find('ymax').text))

if max(x2)<=W and max(y2)<=H:
    print('Okaay')
