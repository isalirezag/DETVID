import os

def XmlToJpeg(input1,input2):
    Output = []
    if len(input1) != 2:
        print('Error!')
    for iii in input1:
        Frame_ii = iii[:-3] + 'JPEG'
        PATHH = Frame_ii.split('/')
        PATHH[-4] = 'Data'
        VideoFramePath = os.path.join('/'.join(PATHH))
        Output.append(VideoFramePath)
    return Output
    