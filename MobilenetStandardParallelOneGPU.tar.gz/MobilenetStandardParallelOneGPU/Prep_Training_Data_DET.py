import pickle
import xml.etree.ElementTree as ET
import os

from scipy.misc import imread


AnnotationPath = '/home/alireza/Datasets/ILSVRC2015/Annotations/DET/train/'

classes_map = ('__background__',  # always index 0
                        'n02691156', 'n02419796', 'n02131653', 'n02834778',
                        'n01503061', 'n02924116', 'n02958343', 'n02402425',
                        'n02084071', 'n02121808', 'n02503517', 'n02118333',
                        'n02510455', 'n02342885', 'n02374451', 'n02129165',
                        'n01674464', 'n02484322', 'n03790512', 'n02324045',
                        'n02509815', 'n02411705', 'n01726692', 'n02355227',
                        'n02129604', 'n04468005', 'n01662784', 'n04530566',
                        'n02062744', 'n02391049')


AllAnnotations= os.listdir (AnnotationPath) # get all files' and folders' names in the current directory
AllAnnotations.sort() # These are all the video files inside

VideoAnnsNames = []
for VideoName in AllAnnotations: # loop through all the files and folders
    if os.path.isdir(os.path.join(os.path.abspath(AnnotationPath), VideoName)):
        # check whether the current object is a folder or not,
        # meaning if there is frames inside the currentvideo folder or not
        VideoAnnsNames.append(os.path.join(os.path.abspath(AnnotationPath), VideoName))

VideoAnnsNames.sort()

DownSample = 1 # this should be one for still images

AnnsVideosAndFrames = {}
AllAnnoInfo = []
AllVideoFramesInfo = []
NOTT = []
Counter = 0
NN = 0
for index, Video in enumerate(VideoAnnsNames[:]):
    Annotation = os.listdir(Video + '/')
    Annotation.sort()
    AnnsVideosAndFrames[Video] = Annotation
#    print('index: {}' .format(index))
    print('index: {} and len {}' .format(index,len(Annotation)))

    for index2, annotation_ii in enumerate(Annotation):

            if index2 % DownSample == 0:
                AnnAddress = Video + '/' + annotation_ii
                tree = ET.parse(AnnAddress).getroot()
                EXIST = any(True for _ in tree.iter('object'))

                if EXIST:
                    objs = tree.findall('object')
                    all_obj_check = []
#                    for obj_check in enumerate(objs):
                    for obj_check in tree.iter('object'):

                        label = obj_check.find('name').text.lower().strip()
                        all_obj_check.append(label)

                    AllObjEXIST = set(all_obj_check).issubset(classes_map)
#                    AllObjEXIST = any(i in all_obj_check for i in classes_map)
                    if AllObjEXIST:
## =============================================================================
                         for sizes in tree.iter('size'):
                             W = float(sizes.find('width').text)
                             H = float(sizes.find('height').text)
                         objs = tree.findall('object')
                         x1, y1, x2, y2 = [], [], [], []
                         # Load object bounding boxes into a data frame.
                         for ix, obj in enumerate(objs):
                             bbox = obj.find('bndbox')
                             x2.append(float(bbox.find('xmax').text))
                             y2.append(float(bbox.find('ymax').text))
                             y1.append(float(bbox.find('ymin').text))
                             x1.append(float(bbox.find('xmin').text))
#                             if min(x1) <= 0 or min(y1) <= 0:
#                                 print(AnnAddress)
                         if max(x2)<W and max(y2)<H and min(x1)>=0 and min(y1)>=0:
# #                        print('Okaay')
## =============================================================================
                            PATHH = Video.split('/')
                            Annotation_INDEX = PATHH.index('Annotations')
                            PATHH[Annotation_INDEX] = 'Data'
                            Frame_ii = annotation_ii[:-3] + 'JPEG'

                            VideoFramePath = os.path.join('/'.join(PATHH),Frame_ii)


#                            im = imread(VideoFramePath)
#                            if im.shape[0] < 50 or im.shape[1] < 50 or len(im.shape) ==4:
#                            if len(im.shape) == 4 or im.shape[0] == 189 and im.shape[1] < 20 :
#                            if len(im.shape) == 3 :
##                                if im.shape[2] == 4:
##
##                                    print(im.shape)
##                                    print(AnnAddress)
#                                    Counter = Counter + 1
#                                    print(Counter)
#                                    print(Counter)
#                                    NOTT.append(VideoFramePath)
#                                else:
#                                    AllAnnoInfo.append(AnnAddress)
#                                    AllVideoFramesInfo.append(VideoFramePath)
#
#                            elif im.shape[0]< 17 or im.shape[1] < 17:
#                                print(im.shape)
#                                print(AnnAddress)
#                                Counter = Counter + 1
#                                print(Counter)
#                                NOTT.append(VideoFramePath)
                            BADD = AnnotationPath + 'n02105855/n02105855_2933.xml'
                            # print(AnnAddress)
#
                            if AnnAddress == BADD:
                                Counter = Counter + 1
                                print(Counter)

                            else:
                                AllAnnoInfo.append(AnnAddress)
                                AllVideoFramesInfo.append(VideoFramePath)



print('Number of images is : {}' .format(len(AllAnnoInfo)))


##len(AllAnnoInfo)
##Out[37]: 17275
#171580
# =============================================================================
# Saving the objects:
f = open('Train_Ann_Frame_Addresses_DET.pckl', 'wb')
pickle.dump([AllVideoFramesInfo, AllAnnoInfo], f)
f.close()
#
# # Getting back the objects:
# f = open('Train_Ann_Frame_Addresses.pckl', 'rb')
# AllVideoFramesInfo, AllAnnoInfo = pickle.load(f)
# f.close()
# =============================================================================
