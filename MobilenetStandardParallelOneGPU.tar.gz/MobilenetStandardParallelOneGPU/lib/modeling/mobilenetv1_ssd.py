import math
import torch
import torch.nn as nn

import torch.nn.functional as F
from torch.autograd import Variable
import os
import sys
from lib.layers import *
#from collections import namedtuple

class _conv_bn(nn.Module):
    def __init__(self, inp, oup, stride):
        super(_conv_bn, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(inp, oup, 3, stride, 1, bias=False),
            nn.BatchNorm2d(oup),
            nn.ReLU(inplace=True),
        )
        self.depth = oup

    def forward(self, x):
        return self.conv(x)

class _conv_bn_ssd(nn.Module):
    def __init__(self, inp, oup):
        super(_conv_bn_ssd, self).__init__()

        self.conv = nn.Sequential(
            nn.Conv2d(inp, oup, 1, 1, 1, bias=False),
            nn.BatchNorm2d(oup),
            nn.ReLU6(inplace=True),

            nn.Conv2d(oup, oup, 3, 2, 1, bias=False),
            nn.BatchNorm2d(oup),
            nn.ReLU6(inplace=True),

            nn.Conv2d(oup, oup, 3, 1, 1, bias=False),
            nn.BatchNorm2d(oup),
        )

    def forward(self, x):
        return self.conv(x)


class _conv_dw(nn.Module):
    def __init__(self, inp, oup, stride):
        super(_conv_dw, self).__init__()
        self.conv = nn.Sequential(
            # dw
            nn.Conv2d(inp, inp, 3, stride, 1, groups=inp, bias=False),
            nn.BatchNorm2d(inp),
            nn.ReLU(inplace=True),
            # pw
            nn.Conv2d(inp, oup, 1, 1, 0, bias=False),
            nn.BatchNorm2d(oup),
            nn.ReLU(inplace=True),
        )
        self.depth = oup

    def forward(self, x):
        return self.conv(x)

class _conv_block(nn.Module):
    def __init__(self, inp, oup, stride=1, expand_ratio=0.5):
        super(_conv_block, self).__init__()
        depth = int(oup*expand_ratio)
        self.conv = nn.Sequential(
            nn.Conv2d(inp, depth, 1, 1, bias=False),
            nn.BatchNorm2d(depth),
            nn.LeakyReLU(0.1, inplace=True),
            nn.Conv2d(depth, oup, 3, stride, 1, bias=False),
            nn.BatchNorm2d(oup),
            nn.LeakyReLU(0.1, inplace=True),
        )

    def forward(self, x):
        return self.conv(x)

class BasicConv(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1, groups=1, relu=True, bn=False, bias=True):
        super(BasicConv, self).__init__()
        self.out_channels = out_planes
        self.conv = nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=padding, dilation=dilation, groups=groups, bias=bias)
        self.bn = nn.BatchNorm2d(out_planes,eps=1e-5, momentum=0.01, affine=True) if bn else None
        self.relu = nn.ReLU(inplace=True) if relu else None
        # self.up_size = up_size
        # self.up_sample = nn.Upsample(size=(up_size,up_size),mode='bilinear') if up_size != 0 else None

    def forward(self, x, up_size=None):
        x = self.conv(x)
        if self.bn is not None:
            x = self.bn(x)
        if self.relu is not None:
            x = self.relu(x)
        if up_size is not None:
            x = F.upsample(x, size=up_size, mode='bilinear')
            # x = self.up_sample(x)
        return x



class MobileNetv1_SSD(nn.Module):
    def __init__(self,  num_classes, feature_layer):
        super(MobileNetv1_SSD, self).__init__()

        self.num_classes = num_classes

        self.base = nn.ModuleList([
            _conv_bn(3, 32, 2),
            _conv_dw(32, 64, 1),
            _conv_dw(64, 128, 2),
            _conv_dw(128, 128, 1),
            _conv_dw(128, 256, 2),
            _conv_dw(256, 256, 1),
            _conv_dw(256, 512, 2),
            _conv_dw(512, 512, 1),
            _conv_dw(512, 512, 1),
            _conv_dw(512, 512, 1),
            _conv_dw(512, 512, 1),
            _conv_dw(512, 512, 1),      #1st feature map
            _conv_dw(512, 1024, 2),
            _conv_dw(1024, 1024, 1),    #2nd feature map
            ])

        self.norm = L2Norm(1024, 20)

        self.extras = nn.ModuleList([
            _conv_bn_ssd(1024, 512),
            _conv_bn_ssd(512, 256),
            _conv_bn_ssd(256, 256),
            _conv_bn_ssd(256, 128),
            ])

        self.loc = nn.ModuleList([
            nn.Conv2d(512, 24, 3, 1, 1, bias=False),
            nn.Conv2d(1024, 24, 3, 1, 1, bias=False),
            nn.Conv2d(512, 24, 3, 1, 1, bias=False),
            nn.Conv2d(256, 24, 3, 1, 1, bias=False),
            nn.Conv2d(256, 16, 3, 1, 1, bias=False),
            nn.Conv2d(128, 16, 3, 1, 1, bias=False),
            ])
        self.conf = nn.ModuleList([
            nn.Conv2d(512, 6 * num_classes, 3, 1, 1, bias=False),
            nn.Conv2d(1024, 6 * num_classes, 3, 1, 1, bias=False),
            nn.Conv2d(512, 6 * num_classes, 3, 1, 1, bias=False),
            nn.Conv2d(256, 6 * num_classes, 3, 1, 1, bias=False),
            nn.Conv2d(256, 4 * num_classes, 3, 1, 1, bias=False),
            nn.Conv2d(128, 4 * num_classes, 3, 1, 1, bias=False)

        ])

        self.softmax = nn.Softmax()

        # print(feature_layer)
        #self.feature_layer = [f for feature in feature_layer[0] for f in feature]
        #self.feature_index = [ len(feature) for feature in feature_layer[0]]
      #  s = -1
       # for feature in feature_layer[0]:
        #    s += len(feature)
         #   self.feature_index.append(s)

    def forward(self, x, phase=None):
        """Applies network layers and ops on input image(s) x.

        Args:
            x: input image or batch of images. Shape: [batch,3*batch,300,300].

        Return:
            Depending on phase:
            test:
                Variable(tensor) of output class label predictions,
                confidence score, and corresponding location predictions for
                each object detected. Shape: [batch,topk,7]

            train:
                list of concat outputs from:
                    1: confidence layers, Shape: [batch*num_priors,num_classes]
                    2: localization layers, Shape: [batch,num_priors*4]
                    3: priorbox layers, Shape: [2,num_priors*4]
        """
        sources, loc, conf = [list() for _ in range(3)]

        #convs until 1st feature map
        for k in range(len(self.base)):
            x = self.base[k](x)
            if k is 11 or k is 13:
                sources.append(x)

        # apply extra layers and cache source layer outputs
        for k in range(len(self.extras)):
            x = self.extras[k](x)
            sources.append(x)

        if phase == 'feature':
            return sources

        # apply multibox head to source layers
        for (x, l, c) in zip(sources, self.loc, self.conf):
            loc.append(l(x).permute(0, 2, 3, 1).contiguous())
            conf.append(c(x).permute(0, 2, 3, 1).contiguous())

        loc = torch.cat([o.view(o.size(0), -1) for o in loc], 1)
        conf = torch.cat([o.view(o.size(0), -1) for o in conf], 1)

        if phase == 'eval':
            output = (
                loc.view(loc.size(0), -1, 4),  # loc preds
                self.softmax(conf.view(-1, self.num_classes)),  # conf preds
            )
        else:
            output = (
                loc.view(loc.size(0), -1, 4),
                conf.view(conf.size(0), -1, self.num_classes),
            )

        return output
