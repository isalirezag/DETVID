import pickle
import xml.etree.ElementTree as ET
import os
#298 + 511
AnnotationPath = '/home/alireza/Datasets/ILSVRC2015/Annotations/VID/train/'

AllAnnotations= os.listdir (AnnotationPath) # get all files' and folders' names in the current directory
AllAnnotations.sort() # These are all the video files inside

VideoAnnsNames = []
for VideoName in AllAnnotations: # loop through all the files and folders
    if os.path.isdir(os.path.join(os.path.abspath(AnnotationPath), VideoName)): # check whether the current object is a folder or not,meaning if there is frames inside the currentvideo folder or not
        VideoAnnsNames.append(os.path.join(os.path.abspath(AnnotationPath), VideoName))

VideoAnnsNames.sort()

DownSample = 10 # every 10 frame

AnnsVideosAndFrames = {}
AllAnnoInfo = []
AllVideoFramesInfo = []
for index, Video in enumerate(VideoAnnsNames[:]):
    Annotation = os.listdir(Video + '/')
    Annotation.sort()
    AnnsVideosAndFrames[Video] = Annotation
#    print('index: {}' .format(index))
    print('index: {} and len {}' .format(index,len(Annotation)))
    for index2, annotation_ii in enumerate(Annotation):
        if len(Annotation)>50:
            if index2 % DownSample == 0:
                AnnAddress = Video + '/' + annotation_ii
                tree = ET.parse(AnnAddress).getroot()
                EXIST = any(True for _ in tree.iter('object'))

                if EXIST:

# =============================================================================
                     for sizes in tree.iter('size'):
                         W = float(sizes.find('width').text)
                         H = float(sizes.find('height').text)
                     objs = tree.findall('object')
                     x1, y1, x2, y2 = [], [], [], []
                     # Load object bounding boxes into a data frame.
                     for ix, obj in enumerate(objs):
                         bbox = obj.find('bndbox')
                         x2.append(float(bbox.find('xmax').text))
                         y2.append(float(bbox.find('ymax').text))
                         y1.append(float(bbox.find('ymin').text))
                         x1.append(float(bbox.find('xmin').text))
                     if max(x2)<W and max(y2)<H and min(x1)>=0 and min(y1)>=0:
 #                        print('Okaay')
# =============================================================================
                        AllAnnoInfo.append(AnnAddress)
                        PATHH = Video.split('/')
                        Annotation_INDEX = PATHH.index('Annotations')
                        PATHH[Annotation_INDEX] = 'Data'
                        Frame_ii = annotation_ii[:-3] + 'JPEG'
                        VideoFramePath = os.path.join('/'.join(PATHH),Frame_ii)
                        AllVideoFramesInfo.append(VideoFramePath)
        else:
#            print('index: {} and len {}' .format(index,len(Annotation)))
            AnnAddress = Video + '/' + annotation_ii
            tree = ET.parse(AnnAddress).getroot()
            EXIST = any(True for _ in tree.iter('object'))
            if EXIST:
# =============================================================================
                 for sizes in tree.iter('size'):
                     W = float(sizes.find('width').text)
                     H = float(sizes.find('height').text)
                 objs = tree.findall('object')
                 x1, y1, x2, y2 = [], [], [], []
                 # Load object bounding boxes into a data frame.
                 for ix, obj in enumerate(objs):
                     bbox = obj.find('bndbox')
                     x2.append(float(bbox.find('xmax').text))
                     y2.append(float(bbox.find('ymax').text))
                     y1.append(float(bbox.find('ymin').text))
                     x1.append(float(bbox.find('xmin').text))
                 if max(x2)<W and max(y2)<H and min(x1)>=0 and min(y1)>=0:
#                     print('Okaay')
# =============================================================================
                     AllAnnoInfo.append(AnnAddress)
                     PATHH = Video.split('/')
                     Annotation_INDEX = PATHH.index('Annotations')
                     PATHH[Annotation_INDEX] = 'Data'
                     Frame_ii = annotation_ii[:-3] + 'JPEG'
                     VideoFramePath = os.path.join('/'.join(PATHH),Frame_ii)
                     AllVideoFramesInfo.append(VideoFramePath)


print('Number of images is : {}' .format(len(AllAnnoInfo)))


##len(AllAnnoInfo)
##Out[37]: 1122397/1084756
##Out[37]: 1122397/88962
#1086128
#1086132
#110013
#00#268447
#VOC = 16551
#166312
#192063
# =============================================================================
# Saving the objects:
f = open('Train_Ann_Frame_Addresses_VID.pckl', 'wb')
pickle.dump([AllVideoFramesInfo, AllAnnoInfo], f)
f.close()
#
# # Getting back the objects:
# f = open('Train_Ann_Frame_Addresses.pckl', 'rb')
# AllVideoFramesInfo, AllAnnoInfo = pickle.load(f)
# f.close()
# =============================================================================
