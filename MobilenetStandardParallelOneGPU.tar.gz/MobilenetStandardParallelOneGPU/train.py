from __future__ import print_function
import numpy as np
import os
import sys
import cv2
import random
import pickle
import argparse

import torch
import torch.backends.cudnn as cudnn
from torch.autograd import Variable
import torch.optim as optim
from torch.optim import lr_scheduler
import torch.utils.data as data
import torch.nn.init as init

from tensorboardX import SummaryWriter

from lib.utils.config_parse import cfg_from_file

from lib.layers import *
from lib.utils.timer import Timer
from lib.utils.data_augment import preproc
from lib.dataset.dataset_factory import load_data
from lib.utils.config_parse import cfg
from lib.utils.eval_utils import *
from lib.utils.visualize_utils import *
from lib.layers.functions.prior_box import PriorBox
from lib.modeling.mobilenetv1_ssd import MobileNetv1_SSD
from lib.flops_benchmark import add_flops_counting_methods
import shutil
os.environ["CUDA_VISIBLE_DEVICES"] = "2"

def parse_args():
    """
    Parse input arguments
    """
    parser = argparse.ArgumentParser(description='Train a ssds.pytorch network')
    parser.add_argument('--cfg', dest='config_file',
            help='optional config file', default=None, type=str)

    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)

    args = parser.parse_args()
    return args



def save_checkpoints(output_dir, checkpoint_prefix, model, epochs, iters=None):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    if iters:
        filename = checkpoint_prefix + '_epoch_{:d}_iter_{:d}'.format(epochs, iters) + '.pth'
    else:
        filename = checkpoint_prefix + '_epoch_{:d}'.format(epochs) + '.pth'
    filename = os.path.join(output_dir, filename)
    if torch.cuda.device_count() > 1:
        torch.save(model.module.state_dict(), filename)
    else:
        torch.save(model.state_dict(), filename)
    with open(os.path.join(output_dir, 'checkpoint_list.txt'), 'a') as f:
        f.write('epoch {epoch:d}: {filename}\n'.format(epoch=epochs, filename=filename))
    print('Wrote snapshot to: {:s}'.format(filename))

def resume_checkpoint(RESUME_SCOPE, model, resume_checkpoint):
    if resume_checkpoint == '' or not os.path.isfile(resume_checkpoint):
        print(("=> no checkpoint found at '{}'".format(resume_checkpoint)))
        return False
    print(("=> loading checkpoint '{:s}'".format(resume_checkpoint)))
    checkpoint = torch.load(resume_checkpoint)

    if torch.cuda.device_count() == 1 and 'module.' in list(checkpoint.items())[0][0]:
        pretrained_dict = {'.'.join(k.split('.')[1:]): v for k, v in list(checkpoint.items())}
        checkpoint = pretrained_dict
        checkpoint.update(pretrained_dict)

        # print("=> Weigths in the checkpoints:")
        # print([k for k, v in list(checkpoint.items())])

#         # remove the module in the parrallel model
#     if 'module.' in list(checkpoint.items())[0][0]:
#         pretrained_dict = {'.'.join(k.split('.')[1:]): v for k, v in list(checkpoint.items())}
#         checkpoint = pretrained_dict

#     resume_scope = RESUME_SCOPE
#         # extract the weights based on the resume scope
#     if resume_scope != '':
#         pretrained_dict = {}
#         for k, v in list(checkpoint.items()):
#             for resume_key in resume_scope.split(','):
#                 if resume_key in k:
#                     pretrained_dict[k] = v
#                     break
#         checkpoint = pretrained_dict

#     pretrained_dict = {k: v for k, v in checkpoint.items() if k in model.state_dict()}
#         # print("=> Resume weigths:")
#         # print([k for k, v in list(pretrained_dict.items())])

#     checkpoint = model.state_dict()

#     unresume_dict = set(checkpoint)-set(pretrained_dict)
#     if len(unresume_dict) != 0:
#         print("=> UNResume weigths:")
#         print(unresume_dict)

#     checkpoint.update(pretrained_dict)

    return model.load_state_dict(checkpoint)


def find_previous(output_dir):
    if not os.path.exists(os.path.join(output_dir, 'checkpoint_list.txt')):
        return False
    with open(os.path.join(output_dir, 'checkpoint_list.txt'), 'r') as f:
        lineList = f.readlines()
    epoches, resume_checkpoints = [list() for _ in range(2)]
    for line in lineList:
        epoch = int(line[line.find('epoch ') + len('epoch '): line.find(':')])
        checkpoint = line[line.find(':') + 2:-1]
        epoches.append(epoch)
        resume_checkpoints.append(checkpoint)
    return epoches, resume_checkpoints

def weights_init(m):
    for key in m.state_dict():
        if key.split('.')[-1] == 'weight':
            if 'conv' in key:
                init.kaiming_normal(m.state_dict()[key], mode='fan_out')
            if 'bn' in key:
                m.state_dict()[key][...] = 1
        elif key.split('.')[-1] == 'bias':
            m.state_dict()[key][...] = 0


def initialize(checkpoint):
        # TODO: ADD INIT ways
        # raise ValueError("Fan in and fan out can not be computed for tensor with less than 2 dimensions")
        # for module in self.cfg.TRAIN.TRAINABLE_SCOPE.split(','):
        #     if hasattr(self.model, module):
        #         getattr(self.model, module).apply(self.weights_init)
    if checkpoint:
        print('Loading initial model weights from {:s}'.format(checkpoint))
        resume_checkpoint(checkpoint)

    start_epoch = 0
    return start_epoch

def trainable_param(model, trainable_scope):
    for param in model.parameters():
        param.requires_grad = False

    trainable_param = []
    for module in trainable_scope.split(','):
        if hasattr(model, module):
            # print(getattr(self.model, module))
            for param in getattr(model, module).parameters():
                param.requires_grad = True
            trainable_param.extend(getattr(model, module).parameters())

    return trainable_param

def configure_lr_scheduler(optimizer, cfg):
    if cfg.SCHEDULER == 'step':
        scheduler = lr_scheduler.StepLR(optimizer, step_size=cfg.STEPS[0], gamma=cfg.GAMMA)
    elif cfg.SCHEDULER == 'multi_step':
        scheduler = lr_scheduler.MultiStepLR(optimizer, milestones=cfg.STEPS, gamma=cfg.GAMMA)
    elif cfg.SCHEDULER == 'exponential':
        scheduler = lr_scheduler.ExponentialLR(optimizer, gamma=cfg.GAMMA)
    elif cfg.SCHEDULER == 'SGDR':
        scheduler = lr_scheduler.CosineAnnealingLR(optimizer, T_max=cfg.MAX_EPOCHS)
    else:
        AssertionError('scheduler can not be recognized.')
    return scheduler

def configure_optimizer(model, trainable_param, cfg):
    if cfg.OPTIMIZER == 'sgd':
        for param in model.parameters():
            param.requires_grad = True
        optimizer = optim.SGD(model.parameters(), lr=cfg.LEARNING_RATE,
                    momentum=cfg.MOMENTUM, weight_decay=cfg.WEIGHT_DECAY)
    # elif cfg.OPTIMIZER == 'rmsprop':
    #     optimizer = optim.RMSprop(trainable_param, lr=cfg.LEARNING_RATE,
    #                 momentum=cfg.MOMENTUM, alpha=cfg.MOMENTUM_2, eps=cfg.EPS, weight_decay=cfg.WEIGHT_DECAY)
    # elif cfg.OPTIMIZER == 'adam':
    #     optimizer = optim.Adam(trainable_param, lr=cfg.LEARNING_RATE,
    #                 betas=(cfg.MOMENTUM, cfg.MOMENTUM_2), eps=cfg.EPS, weight_decay=cfg.WEIGHT_DECAY)
    else:
        AssertionError('optimizer can not be recognized.')
    return optimizer

def _forward_features_size(model, img_size):
    model.eval()
    x = torch.rand(1, 3, img_size[0], img_size[1])
    x = torch.autograd.Variable(x, volatile=True).cuda()
    feature_maps = model(x=x, phase='feature')

    return [(o.size()[2], o.size()[3]) for o in feature_maps]

def flops(model, train_loader):
    model = add_flops_counting_methods(model)
    model = model.cuda().train()
    model.start_flops_count()

    batch_iterator = iter(train_loader)
    images, targets = next(batch_iterator)
    images = Variable(images.cuda())

    _ = model(images)
    flops_mean = model.compute_average_flops_cost() / 1e9 / 2
    print("-----------------------------")
    print("GFLOPS: {}".format(flops_mean))
    print("-----------------------------")

def train():
    args = parse_args()
    if args.config_file is not None:
        cfg_from_file(args.config_file)

    output_dir = cfg.EXP_DIR
    RESUME_SCOPE = cfg.TRAIN.RESUME_SCOPE
    checkpoint = cfg.RESUME_CHECKPOINT
    max_epochs = cfg.TRAIN.MAX_EPOCHS
    checkpoint_prefix = cfg.CHECKPOINTS_PREFIX
    num_classes = cfg.MODEL.NUM_CLASSES
    feature_layer = cfg.MODEL.FEATURE_LAYER

    model = MobileNetv1_SSD(num_classes, feature_layer)


    feature_maps = _forward_features_size(model, cfg.MODEL.IMAGE_SIZE)


    priorbox = PriorBox(image_size=cfg.MODEL.IMAGE_SIZE, feature_maps=feature_maps, aspect_ratios=cfg.MODEL.ASPECT_RATIOS,
                    scale=cfg.MODEL.SIZES, archor_stride=cfg.MODEL.STEPS, clip=cfg.MODEL.CLIP)


    priors = Variable(priorbox.forward(), volatile=True)



    if torch.cuda.is_available():
        print('Utilize GPUs for computation')
        print('Number of GPU available', torch.cuda.device_count())
        if torch.cuda.device_count() > 1:
            model = torch.nn.DataParallel(model)
        model.cuda()
        priors.cuda()
        cudnn.benchmark = True

    criterion = MultiBoxLoss(cfg.MATCHER, priors, torch.cuda.is_available())

    data_loader = load_data(cfg.DATASET, 'train') if 'train' in cfg.PHASE else None

    #flops(model, data_loader)

    print('Trainable scope: {}'.format(cfg.TRAIN.TRAINABLE_SCOPE))
    _trainable_param = trainable_param(model, cfg.TRAIN.TRAINABLE_SCOPE)
    optimizer = configure_optimizer(model, _trainable_param, cfg.TRAIN.OPTIMIZER)


    if os.path.exists(output_dir):
        shutil.rmtree(output_dir)

    exp_lr_scheduler = configure_lr_scheduler(optimizer, cfg.TRAIN.LR_SCHEDULER)

    previous = find_previous(output_dir)
    if previous:
    	start_epoch = previous[0][-1]
    	resume_checkpoint(RESUME_SCOPE, model, previous[1][-1])
    else:
    	start_epoch = 0 #initialize(checkpoint)

    warm_up = cfg.TRAIN.LR_SCHEDULER.WARM_UP_EPOCHS

    for epoch in iter(range(start_epoch+1, max_epochs+1)):
        sys.stdout.write('\rEpoch {epoch:d}/{max_epochs:d}:\n'.format(epoch=epoch, max_epochs=max_epochs))
        if epoch > warm_up:
            exp_lr_scheduler.step(epoch-warm_up)

        model.train()

        epoch_size = len(data_loader)
        batch_iterator = iter(data_loader)

        loc_loss = 0
        conf_loss = 0
        _t = Timer()

        for iteration in iter(range((epoch_size))):
            images, targets = next(batch_iterator)
            if torch.cuda.is_available():
                images = Variable(images.cuda())
                targets = [Variable(anno.cuda(), volatile=True) for anno in targets]
            else:
                images = Variable(images)
                targets = [Variable(anno, volatile=True) for anno in targets]
            _t.tic()
            # forward
            out = model(images, phase='train')

            # backprop
            optimizer.zero_grad()


            loss_l, loss_c = criterion(out, targets)

            # some bugs in coco train2017. maybe the annonation bug.
            if loss_l.data[0] == float("Inf"):
                continue

            loss = loss_l.mean() + loss_c.mean()
            loss.backward()
            optimizer.step()

            time = _t.toc()
            loc_loss += loss_l.data[0]
            conf_loss += loss_c.data[0]
            lr =  optimizer.param_groups[0]['lr']

            # log per iter
            log = '\r==>Train: || {iters:d}/{epoch_size:d} in {time:.3f}s [{prograss}] || loc_loss: {loc_loss:.4f} cls_loss: {cls_loss:.4f} ||  lr: {lr:.6f}\r'.format(
                    prograss='#'*int(round(10*iteration/epoch_size)) + '-'*int(round(10*(1-iteration/epoch_size))), iters=iteration, epoch_size=epoch_size,
                    time=time, loc_loss=loss_l.data[0], cls_loss=loss_c.data[0],lr=lr)

            sys.stdout.write(log)
            sys.stdout.flush()

        # log per epoch
        sys.stdout.write('\r')
        sys.stdout.flush()
        lr = optimizer.param_groups[0]['lr']
        log = '\r==>Train: || Total_time: {time:.3f}s || loc_loss: {loc_loss:.4f} conf_loss: {conf_loss:.4f} || lr: {lr:.6f}\n'.format(lr=lr,
                time=_t.total_time, loc_loss=loc_loss/epoch_size, conf_loss=conf_loss/epoch_size)
        sys.stdout.write(log)
        sys.stdout.flush()

        # log for tensorboard
#         writer.add_scalar('Train/loc_loss', loc_loss/epoch_size, epoch)
#         writer.add_scalar('Train/conf_loss', conf_loss/epoch_size, epoch)
#         writer.add_scalar('Train/lr', lr, epoch)

        if epoch % cfg.TRAIN.CHECKPOINTS_EPOCHS == 0:
        	save_checkpoints(output_dir, checkpoint_prefix, model, epoch)

if __name__ == '__main__':
    train()
